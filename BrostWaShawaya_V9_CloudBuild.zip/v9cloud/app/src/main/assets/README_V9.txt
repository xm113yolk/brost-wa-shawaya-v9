بروست وشواية المدينة — V9 Production

تم تجهيز النسخة لتعمل فعلياً مع Supabase بدلاً من localStorage.

التغييرات:
- تسجيل الدخول هو الشاشة الأولى.
- لا توجد بيانات تجريبية ظاهرة في الشاشة.
- إزالة قسم «مراحل النظام القادمة».
- تسجيل الدخول عبر employee_login في Supabase.
- الطلبات والتوريدات والموظفون تُقرأ وتُحفظ في Supabase.
- تحديثات الطلبات عبر Supabase Realtime.
- صوت وتنبيه عند وصول طلب جديد للمندوب أثناء تشغيل التطبيق/الواجهة.
- استخدام Publishable Key فقط.

متطلبات Supabase:
- تفعيل Anonymous Sign-Ins.
- تشغيل supabase_schema_brost_wa_shawaya.sql.
- تفعيل Realtime لجدول orders و supplies.

ملاحظة:
هذه حزمة الواجهة الإنتاجية. بناء APK النهائي يحتاج Android SDK/بيئة بناء Android.
النسخة لا تعتمد على localStorage للبيانات التشغيلية.
