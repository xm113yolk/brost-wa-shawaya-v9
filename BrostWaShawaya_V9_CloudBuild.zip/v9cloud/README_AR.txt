مشروع بروست وشواية المدينة - Android V9

هذا مشروع Android Studio جاهز كبداية لتغليف نسخة V9 داخل APK.
يفتح index.html من assets داخل WebView، مع صلاحية الإنترنت وإذن إشعارات Android.

مهم:
- الاتصال بـ Supabase يعتمد على إعدادات/كود V9 الموجود داخل index.html.
- إشعارات Push الحقيقية أثناء إغلاق التطبيق ليست مضمونة بمجرد WebView؛ تحتاج Firebase/FCM أو Web Push/Service Worker.
- بناء APK يحتاج Android SDK/Gradle أو Android Studio.
