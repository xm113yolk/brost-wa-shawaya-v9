# بناء APK من الهاتف فقط

1. أنشئ مستودع GitHub جديدًا.
2. ارفع محتويات هذا المشروع إلى المستودع (وليس ملف ZIP نفسه).
3. افتح تبويب Actions.
4. اختر Build Brost Wa Shawaya APK.
5. اضغط Run workflow إذا كان البناء اليدوي ظاهرًا، أو ادفع Commit جديدًا إلى main.
6. بعد نجاح البناء افتح صفحة التشغيل ثم قسم Artifacts.
7. نزّل BrostWaShawaya-V9-APKs.zip واستخرج APK.

سيتم إنشاء:
- app-debug.apk: أسهل ملف للاختبار والتثبيت.
- app-release-unsigned.apk: نسخة Release غير موقعة؛ لا تستخدمها للتوزيع حتى يتم توقيعها بمفتاح إصدار خاص.

ملاحظة: GitHub Actions يبني المشروع على خوادم GitHub، ولا يحتاج Termux أو AndroidIDE على الهاتف.
